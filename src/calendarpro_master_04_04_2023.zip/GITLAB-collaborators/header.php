<head>
    <link rel="stylesheet" href="CalendarTheme.css">
</head>

<body>
        <nav class="navbar navbar-expand-sm navbar-dark bg-dark">
        <div class="container-fluid">
             <a class="navbar-brand col-sm-2" href="index.php"> <img src="./img/logo.png" width="50px" height="50px"> </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mynavbar">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="user.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="public.php">Register</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="admin.php">Shared Calendar</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</body>
