Login happens in public.php
