<!DOCTYPE html>
<html>
<head>
	<title>Update Successful! You will be redirected soon</title>
        <meta http-equiv="refresh" content="2;url=index.php" />
</head>
<body>
	<h1>Successful Update! You will be redirected soon</h1>
</body>
</html>
