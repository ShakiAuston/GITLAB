<!DOCTYPE html>
<html>
<head>
	<title>Update Failed! Your input to the form was wrong</title>
        <meta http-equiv="refresh" content="2;url=update_failed.php" />
</head>
<body>
	<h1>Failed Update! You will be redirected soon</h1>
</body>
</html>