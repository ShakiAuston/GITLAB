<!DOCTYPE html>
<html>
<head>
	<title>Update Failed! You will be redirected soon</title>
        <meta http-equiv="refresh" content="10;url=index.php" />
</head>
<body>
	<h1>Failed Update! You will be redirected soon</h1>
</body>
</html>