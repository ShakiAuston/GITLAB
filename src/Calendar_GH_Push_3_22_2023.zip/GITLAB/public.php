<!-- Calendar Public Login Page -->
<head>
    <link rel="stylesheet" href="CalendarTheme.css">
    <h1>BookIt Calendar</h1>
</head>
<br>
<body>
    <b>Please login or signup to continue</b>
</body>
