<!-- Calendar Public Login Page -->
<head>
    <link rel="stylesheet" href="CalendarTheme.css">
    <h1>Welcome to the Calendar! Please Login or sign up to continue</h1>
</head>
<br>
