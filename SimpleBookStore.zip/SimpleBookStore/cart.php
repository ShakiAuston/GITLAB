<?php

$title = $_GET['Title'];
$price = $_GET['Price'];
echo '<h2>You ordered '.$title.' and its price is $'.$price;

?>