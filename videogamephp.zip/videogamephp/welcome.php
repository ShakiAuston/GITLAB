<?php 
include 'header.php'; 
if (!(isset($_SESSION['name']))) {
  header("Location:index.php");
  exit;
}
?>

<div class="container-fluid">
  <div class="w3-container w3-pink">
    <div class="row">
      <div class="col-sm-10 w3-center"><h1>Welcome To Logan's Video Games!</h1></div>
      <p>Welcome to Logan's Video Games browse our selections of video games and purchase them.</p>
    </div>
  </div>  

